#!/bin/bash

# remove old ssl link, they are just soft link, so don't worry
sudo rm -f /lib/x86_64-linux-gnu/libssl.so
sudo rm -f /lib/x86_64-linux-gnu/libcrypto.so

# copy 1.1 version to your folders
sudo cp libssl.so.1.1 /lib/x86_64-linux-gnu/
sudo cp libcrypto.so.1.1 /lib/x86_64-linux-gnu/

# do the linking
sudo ln -s /lib/x86_64-linux-gnu/libssl.so.1.1 /lib/x86_64-linux-gnu/libssl.so
sudo ln -s /lib/x86_64-linux-gnu/libcrypto.so.1.1 /lib/x86_64-linux-gnu/libcrypto.so

# done
echo "We are done, hope everything goes right"
